import SwiftUI

@main
struct @@PROJECTNAME@@App: App {
	var body: some Scene {
		WindowGroup {
			ContentView()
		}
	}
}
