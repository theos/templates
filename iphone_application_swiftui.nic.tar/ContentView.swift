import SwiftUI

struct ContentView: View {
    @State private var items = [Date]()

    var body: some View {
        NavigationView {
            VStack {
                List {
                    ForEach(items, id: \.self) { item in
                        Text(item.description)
                    }
                    .onDelete(perform: delete)
                }.toolbar {
                    ToolbarItem(placement: .navigationBarLeading) {
                        EditButton()
                    }
                }
                .listStyle(InsetGroupedListStyle())
            }
            .navigationTitle("Content View")
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button(action: {
                        withAnimation(.easeInOut) {
                            items.insert(Date(), at: 0)
                        }
                    }) {
                        Image(systemName: "plus")
                    }
                }
            }
        }
    }

    func delete(at offsets: IndexSet) {
        items.remove(atOffsets: offsets)
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
