#import "@@CLASSPREFIX@@XPCProtocol.h"

@interface @@CLASSPREFIX@@XPC : NSObject <@@CLASSPREFIX@@XPCProtocol>
@end
