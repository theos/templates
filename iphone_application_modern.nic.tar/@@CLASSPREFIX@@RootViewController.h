#import <UIKit/UIKit.h>

@interface @@CLASSPREFIX@@RootViewController : UITableViewController

@end
