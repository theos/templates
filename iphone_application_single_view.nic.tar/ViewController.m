#import "ViewController.h"




@interface ViewController ()
//private interface


@end


@implementation ViewController {
	
}

- (void)loadView {
	[super loadView];
	
	
	
	self.view.backgroundColor = [UIColor whiteColor];
	
	
	
	
}

- (void)viewDidLoad {
	
	// do anything after the view loads
	
	
	
}


@end
