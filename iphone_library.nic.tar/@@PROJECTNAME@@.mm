int main(int argc, char **argv, char **envp) {
	return 0;
}

// vim:ft=objc
