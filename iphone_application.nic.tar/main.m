#import <Foundation/Foundation.h>
#import "@@CLASSPREFIX@@AppDelegate.h"

int main(int argc, char *argv[]) {
	@autoreleasepool {
		return UIApplicationMain(argc, argv, nil, NSStringFromClass(@@CLASSPREFIX@@AppDelegate.class));
	}
}
