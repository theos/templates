let dateElement = document.getElementById('date');

dateElement.textContent = new Date();