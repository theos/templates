#import "Headers.h"

@interface @@PROJECTNAME@@ViewController : _SBUIWidgetViewController

@end
