//myScene.h 


#import <SpriteKit/SpriteKit.h>
@interface myScene : SKScene <SKPhysicsContactDelegate>
	-(instancetype)initWithSize:(CGSize)size;
	
	
	
@end

