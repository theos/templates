#import <SpriteKit/SpriteKit.h>

@interface menuScene : SKScene

@property (nonatomic, strong) SKLabelNode *title;

@property (nonatomic, strong) SKSpriteNode *startBtn;
@end