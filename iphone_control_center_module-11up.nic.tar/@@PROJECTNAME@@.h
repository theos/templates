#import <ControlCenterUIKit/CCUIToggleModule.h>

@interface @@PROJECTNAME@@ : CCUIToggleModule

@end
