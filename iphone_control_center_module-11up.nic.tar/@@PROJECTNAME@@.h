#import <ControlCenterUIKit/CCUIToggleModule.h>

@interface @@PROJECTNAME@@ : CCUIToggleModule {
    BOOL _selected;
}

@end
